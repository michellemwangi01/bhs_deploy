import React from "react";

const LandingPageAdmission = () => {
  return <div className="landing-page-admission">LandingPageAdmission</div>;
};

export default LandingPageAdmission;
