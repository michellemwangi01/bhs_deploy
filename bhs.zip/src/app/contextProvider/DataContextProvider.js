import React, { createContext, useState, useEffect } from "react";
import { useSpring, animated } from "react-spring";

const dataContext = createContext();
